<?php
// config.php - настройки подключения к базе данных
// Включаем отображение ошибок (для отладки)
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Устанавливаем кодировку
header('Content-Type: text/html; charset=utf-8');
// ============================================
// ПАРАМЕТРЫ ПОДКЛЮЧЕНИЯ К БАЗЕ ДАННЫХ
// ============================================

// Адрес сервера (для XAMPP используем localhost)
define('DB_HOST', 'localhost'); 
// Имя пользователя базы данных
define('DB_USER', 'root');
// Пароль (по умолчанию в OpenServer пустой)
define('DB_PASS', '');
// Имя базы данных
define('DB_NAME', 'test_db');
// ============================================
// ФУНКЦИЯ ПОДКЛЮЧЕНИЯ К БД
// ============================================
function getConnection() {
// Создаем подключение
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
// Проверяем подключение
if ($conn->connect_error) {
die("Ошибка подключения: " . $conn->connect_error);
}
// Устанавливаем кодировку для русского языка
$conn->set_charset("utf8mb4");
return $conn;
}
// ============================================
// ФУНКЦИЯ ЗАКРЫТИЯ ПОДКЛЮЧЕНИЯ
// ============================================
function closeConnection($conn) {
if ($conn) {
$conn->close();
}
}
?>