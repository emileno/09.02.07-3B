<?php
// edit_user.php - редактирование пользователя
require_once 'config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header('Location: users.php');
    exit;
}

$conn = getConnection();

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $email    = $_POST['email'] ?? '';
    $age      = (int)($_POST['age'] ?? 0);

    if (!empty($username) && !empty($email) && $age > 0) {
        $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, age = ? WHERE id = ?");
        $stmt->bind_param("ssii", $username, $email, $age, $id);

        if ($stmt->execute()) {
            $stmt->close();
            closeConnection($conn);
            header('Location: users.php?success=2');
            exit;
        } else {
            $stmt->close();
            closeConnection($conn);
            header('Location: users.php?error=1');
            exit;
        }
    } else {
        header('Location: edit_user.php?id=' . $id . '&error=1');
        exit;
    }
}

// Загружаем текущие данные пользователя
$stmt = $conn->prepare("SELECT id, username, email, age FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
closeConnection($conn);

if (!$user) {
    header('Location: users.php');
    exit;
}

$editError = isset($_GET['error']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактировать: <?php echo htmlspecialchars($user['username']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>✏️ Редактирование пользователя</h1>

    <div class="menu">
        <a href="index.php" class="btn">Главная</a>
        <a href="users.php" class="btn">← Список пользователей</a>
        <a href="user_detail.php?id=<?php echo $user['id']; ?>" class="btn">👤 Профиль</a>
    </div>

    <?php if ($editError): ?>
        <div class="error-message">❌ Заполните все поля корректно</div>
    <?php endif; ?>

    <div class="add-form">
        <h3>Данные пользователя (ID: <?php echo $user['id']; ?>)</h3>
        <form method="POST" action="edit_user.php?id=<?php echo $user['id']; ?>">
            <div class="form-group">
                <label>Имя пользователя</label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label>Возраст</label>
                <input type="number" name="age" value="<?php echo $user['age']; ?>" required>
            </div>
            <button type="submit" class="btn-submit">💾 Сохранить изменения</button>
            <a href="users.php" class="btn" style="margin-left: 10px;">Отмена</a>
        </form>
    </div>
</div>
</body>
</html>
