<?php
// users.php - вывод списка пользователей из БД
require_once 'config.php';

// В самом начале файла, после require_once 'config.php';
$success = isset($_GET['success']) ? $_GET['success'] : null;
$error = isset($_GET['error']) ? $_GET['error'] : null;

// Получаем подключение к БД
$conn = getConnection();

// ============================================
// 1. ВЫПОЛНЯЕМ SQL-ЗАПРОС С ЗАДАНИЯМИ:
//    - Только пользователи старше 20 лет (age > 20)
//    - Сортировка по возрасту от младших к старшим (ORDER BY age ASC)
//    - Email содержит "mail.ru" (email LIKE '%mail.ru%')
// ============================================
$sql = "SELECT id, username, email, age, created_at 
        FROM users 
        WHERE age > 20 
        AND email LIKE '%mail.ru%'
        ORDER BY age ASC";
        
$result = $conn->query($sql);

// ============================================
// 2. ПРОВЕРЯЕМ, ЕСТЬ ЛИ ДАННЫЕ
// ============================================
$users = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Список пользователей</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>👥 Список пользователей</h1>
    
    <?php if ($success == 1): ?>
        <div class="success-message">✅ Пользователь успешно добавлен!</div>
    <?php elseif ($success == 2): ?>
        <div class="success-message">✅ Данные пользователя обновлены!</div>
    <?php elseif ($success == 3): ?>
        <div class="success-message">✅ Пользователь удалён!</div>
    <?php endif; ?>

    <?php if ($error == 1): ?>
        <div class="error-message">❌ Ошибка при выполнении операции</div>
    <?php endif; ?>
    
    <div class="menu">
        <a href="index.php" class="btn">Главная</a>
        <a href="users.php" class="btn btn-active">Список пользователей</a>
    </div>
    
    <div class="info">
        <p>Всего пользователей (старше 20 лет, с email на mail.ru): <strong><?php echo count($users); ?></strong></p>
    </div>
    
    <?php if (empty($users)): ?>
        <div class="warning">
            ⚠️ Нет пользователей, соответствующих критериям:<br>
            - Возраст старше 20 лет<br>
            - Email содержит "mail.ru"
        </div>
    <?php else: ?>
        <table class="users-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Имя пользователя</th>
                    <th>Email</th>
                    <th>Возраст</th>
                    <th>Дата регистрации</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><a href="user_detail.php?id=<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></a></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo $user['age']; ?></td>
                    <td><?php echo $user['created_at']; ?></td>
                    <td class="actions">
                        <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn-edit">✏️ Редактировать</a>
                        <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn-delete" onclick="return confirm('Удалить пользователя «<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>»?')">🗑️ Удалить</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- Форма добавления пользователя -->
    <div class="add-form">
        <h3>➕ Добавить нового пользователя</h3>
        <form method="POST" action="add_user.php">
            <div class="form-group">
                <input type="text" name="username" placeholder="Имя пользователя" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="number" name="age" placeholder="Возраст" required>
            </div>
            <button type="submit" class="btn-submit">Добавить</button>
        </form>
    </div>

    <div class="code-example">
        <h3>💻 PHP-код для запроса (с выполненными заданиями):</h3>
        <pre><code>
// 1. Только пользователи старше 20 лет
// 2. Сортировка по возрасту (от младших к старшим)
// 3. Email содержит "mail.ru"

$sql = "SELECT id, username, email, age, created_at 
        FROM users 
        WHERE age > 20 
        AND email LIKE '%mail.ru%'
        ORDER BY age ASC";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    echo $row['username'] . " - " . $row['email'] . " (возраст: " . $row['age'] . ")";
}
        </code></pre>
    </div>
</div>

<?php closeConnection($conn); ?>
</body>
</html>