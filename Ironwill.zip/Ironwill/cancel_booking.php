<?php
require_once 'functions.php';
requireAuth();

$user_login = $_SESSION['user_login'];

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    if (deleteBooking($id, $user_login)) {
        header('Location: my_bookings.php?cancelled=1');
        exit();
    }
}

header('Location: my_bookings.php?error=1');
exit();
?>