<?php
session_start();

// ==================== ПОДКЛЮЧЕНИЕ К БАЗЕ ДАННЫХ С ПЕРЕБОРОМ ХОСТОВ ====================
function getDB() {
    static $pdo = null;
    
    if ($pdo === null) {
        // Пробуем разные хосты по очереди
        $hosts = [
            '127.0.1.27',
            '127.0.1.28', 
            '127.0.0.1',
            'localhost',
            '::1'
        ];
        
        $ports = [3306, 3307]; // Стандартные порты MySQL
        $dbname = 'ironwill';
        $username = 'root';
        $password = '';
        
        $connected = false;
        $lastError = '';
        
        // Пробуем все комбинации хост + порт
        foreach ($hosts as $host) {
            foreach ($ports as $port) {
                try {
                    $pdo = new PDO(
                        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
                        $username,
                        $password,
                        [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                            PDO::ATTR_EMULATE_PREPARES => false,
                            PDO::ATTR_TIMEOUT => 3
                        ]
                    );
                    
                    // Если подключились успешно
                    $connected = true;
                    break 2; // Выходим из обоих циклов
                    
                } catch(PDOException $e) {
                    $lastError = $e->getMessage();
                    // Продолжаем пробовать следующую комбинацию
                }
            }
        }
        
        // Если не подключились с портами, пробуем без указания порта
        if (!$connected) {
            foreach ($hosts as $host) {
                try {
                    $pdo = new PDO(
                        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                        $username,
                        $password,
                        [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                            PDO::ATTR_EMULATE_PREPARES => false,
                            PDO::ATTR_TIMEOUT => 3
                        ]
                    );
                    
                    $connected = true;
                    break;
                    
                } catch(PDOException $e) {
                    $lastError = $e->getMessage();
                }
            }
        }
        
        // Если все равно не подключились - показываем информативную ошибку
        if (!$connected) {
            $hostsList = implode(', ', $hosts);
            die("
            <div style='max-width:600px;margin:50px auto;padding:20px;background:#1a1a2e;color:#eee;border-radius:10px;font-family:sans-serif;'>
                <h2 style='color:#c0392b;'>❌ Ошибка подключения к базе данных</h2>
                <p><strong>Последняя ошибка:</strong> " . htmlspecialchars($lastError) . "</p>
                
                <h3 style='color:#f39c12;'>Проверенные хосты:</h3>
                <ul>
                    <li>$hostsList</li>
                </ul>
                
                <h3 style='color:#f39c12;'>Решения:</h3>
                <ol>
                    <li>Убедитесь, что MySQL запущен (проверьте OpenServer/XAMPP)</li>
                    <li>Создайте базу данных 'ironwill' через phpMyAdmin</li>
                    <li>Проверьте порт MySQL (обычно 3306 или 3307)</li>
                    <li>Запустите <code>test_db.php</code> для диагностики</li>
                </ol>
                
                <h3 style='color:#f39c12;'>SQL для создания БД:</h3>
                <pre style='background:#0f3460;padding:10px;border-radius:5px;'>
CREATE DATABASE IF NOT EXISTS ironwill 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;</pre>
            </div>
            ");
        }
    }
    
    return $pdo;
}

// ==================== СОЗДАНИЕ ТАБЛИЦ ====================
function initDatabase() {
    try {
        $pdo = getDB();
        
        // Таблица пользователей
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            login VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            reg_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            remember_token VARCHAR(64) DEFAULT NULL,
            INDEX idx_login (login),
            INDEX idx_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Таблица тренировок
        $pdo->exec("CREATE TABLE IF NOT EXISTS workouts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            type ENUM('group', 'personal') NOT NULL,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            datetime DATETIME NOT NULL,
            max_participants INT NOT NULL DEFAULT 10,
            created_by VARCHAR(50) NOT NULL,
            INDEX idx_datetime (datetime),
            INDEX idx_type (type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Таблица записей на тренировки
        $pdo->exec("CREATE TABLE IF NOT EXISTS bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            workout_id INT NOT NULL,
            user_login VARCHAR(50) NOT NULL,
            booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (workout_id) REFERENCES workouts(id) ON DELETE CASCADE,
            INDEX idx_user (user_login),
            INDEX idx_workout (workout_id),
            UNIQUE KEY unique_booking (workout_id, user_login)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
    } catch(PDOException $e) {
        // Если база данных не существует, пробуем создать её
        if ($e->getCode() == 1049) {
            try {
                // Подключаемся без указания БД
                foreach ([
                    ['host' => '127.0.1.27', 'port' => 3306],
                    ['host' => '127.0.1.28', 'port' => 3306],
                    ['host' => '127.0.0.1', 'port' => 3306],
                    ['host' => 'localhost', 'port' => 3306],
                    ['host' => '127.0.0.1', 'port' => 3307],
                    ['host' => 'localhost', 'port' => 3307]
                ] as $config) {
                    try {
                        $tempPdo = new PDO(
                            "mysql:host={$config['host']};port={$config['port']};charset=utf8mb4",
                            'root',
                            '',
                            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                        );
                        
                        // Создаем базу данных
                        $tempPdo->exec("CREATE DATABASE IF NOT EXISTS ironwill CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                        
                        // Пробуем снова инициализировать таблицы
                        initDatabase();
                        return;
                        
                    } catch(PDOException $ex) {
                        continue;
                    }
                }
            } catch(PDOException $ex) {
                die("Не удалось создать базу данных: " . $ex->getMessage());
            }
        }
    }
}

// Инициализируем таблицы при первом запуске
initDatabase();

// ==================== ПОЛЬЗОВАТЕЛИ ====================
function getAllUsers() {
    $pdo = getDB();
    $stmt = $pdo->query("SELECT * FROM users ORDER BY reg_date DESC");
    return $stmt->fetchAll();
}

function findUserByLogin($login) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    return $stmt->fetch();
}

function saveUser($user) {
    $pdo = getDB();
    $stmt = $pdo->prepare("INSERT INTO users (login, password, name, email, reg_date) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([
        $user['login'],
        $user['password'],
        $user['name'],
        $user['email'],
        $user['reg_date'] ?? date('Y-m-d H:i:s')
    ]);
}

function updateUser($login, $newData) {
    $pdo = getDB();
    
    $fields = [];
    $values = [];
    
    foreach ($newData as $key => $value) {
        $fields[] = "$key = ?";
        $values[] = $value;
    }
    
    $values[] = $login;
    $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE login = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($values);
}

// ==================== ТРЕНИРОВКИ ====================
function getAllWorkouts() {
    $pdo = getDB();
    $stmt = $pdo->query("SELECT * FROM workouts ORDER BY datetime ASC");
    return $stmt->fetchAll();
}

function getWorkoutById($id) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM workouts WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function saveWorkout($data) {
    $pdo = getDB();
    $stmt = $pdo->prepare("INSERT INTO workouts (type, title, description, datetime, max_participants, created_by) VALUES (?, ?, ?, ?, ?, ?)");
    return $stmt->execute([
        $data['type'],
        $data['title'],
        $data['description'],
        $data['datetime'],
        $data['max_participants'],
        $data['created_by']
    ]);
}

// ==================== ЗАПИСИ НА ТРЕНИРОВКИ ====================
function getAllBookings() {
    $pdo = getDB();
    $stmt = $pdo->query("SELECT * FROM bookings ORDER BY booking_date DESC");
    return $stmt->fetchAll();
}

function getBookingsByUser($user_login) {
    $pdo = getDB();
    $stmt = $pdo->prepare("
        SELECT b.*, w.type, w.title, w.description, w.datetime, w.max_participants, w.created_by 
        FROM bookings b 
        JOIN workouts w ON b.workout_id = w.id 
        WHERE b.user_login = ? 
        ORDER BY w.datetime ASC
    ");
    $stmt->execute([$user_login]);
    $bookings = $stmt->fetchAll();
    
    // Форматируем данные в старом формате для совместимости
    $result = [];
    foreach ($bookings as $b) {
        $result[] = [
            'id' => $b['id'],
            'workout_id' => $b['workout_id'],
            'user_login' => $b['user_login'],
            'booking_date' => $b['booking_date'],
            'workout' => [
                'id' => $b['workout_id'],
                'type' => $b['type'],
                'title' => $b['title'],
                'description' => $b['description'],
                'datetime' => $b['datetime'],
                'max_participants' => $b['max_participants'],
                'created_by' => $b['created_by']
            ]
        ];
    }
    
    return $result;
}

function createBooking($user_login, $workout_id) {
    $pdo = getDB();
    try {
        $stmt = $pdo->prepare("INSERT INTO bookings (workout_id, user_login, booking_date) VALUES (?, ?, ?)");
        return $stmt->execute([$workout_id, $user_login, date('Y-m-d H:i:s')]);
    } catch (PDOException $e) {
        // Если запись уже существует
        if ($e->getCode() == 23000) {
            return false;
        }
        throw $e;
    }
}

function deleteBooking($id, $user_login) {
    $pdo = getDB();
    $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = ? AND user_login = ?");
    $stmt->execute([$id, $user_login]);
    return $stmt->rowCount() > 0;
}

function isUserBooked($user_login, $workout_id) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM bookings WHERE user_login = ? AND workout_id = ?");
    $stmt->execute([$user_login, $workout_id]);
    $result = $stmt->fetch();
    return $result['count'] > 0;
}

function getBookingCountForWorkout($workout_id) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM bookings WHERE workout_id = ?");
    $stmt->execute([$workout_id]);
    $result = $stmt->fetch();
    return $result['count'];
}

// ==================== ВАЛИДАЦИЯ ====================
function validateLogin($login) {
    if (strlen($login) < 3) return 'Логин должен быть не менее 3 символов';
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) return 'Логин может содержать только буквы, цифры и _';
    return '';
}

function validatePassword($password) {
    if (strlen($password) < 6) return 'Пароль должен быть не менее 6 символов';
    return '';
}

function validateName($name) {
    if (strlen($name) < 2) return 'Имя должно быть не менее 2 символов';
    if (!preg_match('/^[a-zA-Zа-яА-ЯёЁ\s\-]+$/u', $name)) return 'Имя может содержать только буквы, пробелы и дефис';
    return '';
}

function validateEmail($email) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return 'Некорректный email';
    return '';
}

// ==================== АУТЕНТИФИКАЦИЯ ====================
function registerUser($login, $password, $name, $email) {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    return saveUser([
        'login' => $login,
        'password' => $hash,
        'name' => $name,
        'email' => $email,
        'reg_date' => date('Y-m-d H:i:s')
    ]);
}

function loginUser($login, $password, $remember = false) {
    $user = findUserByLogin($login);
    if (!$user) return false;
    if (!password_verify($password, $user['password'])) return false;

    $_SESSION['user_login'] = $user['login'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];

    if ($remember) {
        $token = bin2hex(random_bytes(32));
        setcookie('remember_token', $token, time() + 60 * 60 * 24 * 30, '/');
        setcookie('remember_login', $login, time() + 60 * 60 * 24 * 30, '/');
        
        // Сохраняем токен в БД
        $pdo = getDB();
        $stmt = $pdo->prepare("UPDATE users SET remember_token = ? WHERE login = ?");
        $stmt->execute([$token, $login]);
    }

    return true;
}

function logoutUser() {
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    setcookie('remember_login', '', time() - 3600, '/');
}

function isLoggedIn() {
    if (isset($_SESSION['user_login'])) return true;

    // Проверка cookie "Запомнить меня"
    if (isset($_COOKIE['remember_login'], $_COOKIE['remember_token']) && !isset($_SESSION['user_login'])) {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ? AND remember_token = ?");
        $stmt->execute([$_COOKIE['remember_login'], $_COOKIE['remember_token']]);
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_login'] = $user['login'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            return true;
        }
    }

    return false;
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    
    $login = $_SESSION['user_login'] ?? null;
    if (!$login) return null;
    
    $user = findUserByLogin($login);
    
    // Проверяем, что пользователь найден и имеет все необходимые поля
    if ($user && isset($user['login'])) {
        return $user;
    }
    
    return null;
}

function requireAuth() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// ==================== ИНИЦИАЛИЗАЦИЯ ДАННЫХ ====================
function initSampleWorkouts() {
    $workouts = getAllWorkouts();
    if (count($workouts) > 0) return;
    
    $sampleWorkouts = [
        ['type' => 'group', 'title' => 'Йога для начинающих', 'description' => 'Расслабляющая практика для всех уровней подготовки', 'datetime' => '2026-05-10 10:00', 'max_participants' => 15, 'created_by' => 'admin'],
        ['type' => 'group', 'title' => 'Силовая тренировка', 'description' => 'Интенсивная работа с весами для роста мышц', 'datetime' => '2026-05-10 12:00', 'max_participants' => 10, 'created_by' => 'admin'],
        ['type' => 'personal', 'title' => 'Персональная тренировка с тренером', 'description' => 'Индивидуальная программа под ваш уровень', 'datetime' => '2026-05-11 09:00', 'max_participants' => 1, 'created_by' => 'admin'],
        ['type' => 'group', 'title' => 'Кардио-микс', 'description' => 'Аэробная тренировка для сжигания калорий', 'datetime' => '2026-05-11 18:00', 'max_participants' => 20, 'created_by' => 'admin'],
        ['type' => 'group', 'title' => 'Растяжка и гибкость', 'description' => 'Улучшение подвижности суставов и эластичности мышц', 'datetime' => '2026-05-12 11:00', 'max_participants' => 12, 'created_by' => 'admin'],
    ];
    
    foreach ($sampleWorkouts as $w) {
        saveWorkout($w);
    }
}

// Инициализация при первом запуске
initSampleWorkouts();
?>