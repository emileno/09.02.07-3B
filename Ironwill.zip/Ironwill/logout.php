<?php
require_once 'functions.php';

logoutUser();
header('Location: login.php');
exit();
?>