<?php
require_once 'functions.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$errors = [];
$success = '';
$login = $name = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // Валидация
    $error = validateLogin($login);
    if ($error) $errors[] = $error;

    $error = validatePassword($password);
    if ($error) $errors[] = $error;

    if ($password !== $confirm_password) $errors[] = 'Пароли не совпадают';

    $error = validateName($name);
    if ($error) $errors[] = $error;

    $error = validateEmail($email);
    if ($error) $errors[] = $error;

    if (findUserByLogin($login)) $errors[] = 'Пользователь с таким логином уже существует';

    if (empty($errors)) {
        registerUser($login, $password, $name, $email);
        $success = 'Регистрация успешна! Теперь вы можете <a href="login.php">войти</a>.';
        $login = $name = $email = '';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IronWill — Регистрация</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #1a1a2e; color: #eee; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .container { background: #16213e; padding: 30px; border-radius: 12px; width: 100%; max-width: 420px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); }
        h1 { text-align: center; color: #f39c12; margin-bottom: 20px; }
        .logo { font-size: 28px; font-weight: bold; text-align: center; margin-bottom: 10px; }
        label { display: block; margin-top: 14px; font-weight: 600; }
        input[type="text"], input[type="password"], input[type="email"] { width: 100%; padding: 12px; margin-top: 4px; border: none; border-radius: 6px; background: #0f3460; color: #fff; font-size: 14px; }
        button { width: 100%; padding: 12px; margin-top: 20px; background: #f39c12; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; color: #1a1a2e; cursor: pointer; }
        button:hover { background: #e67e22; }
        .error-box { background: #c0392b; padding: 10px; border-radius: 6px; margin-top: 14px; font-size: 13px; }
        .success-box { background: #27ae60; padding: 10px; border-radius: 6px; margin-top: 14px; font-size: 13px; }
        a { color: #f39c12; }
        .links { text-align: center; margin-top: 16px; font-size: 13px; }
    </style>
</head>
<body>
<div class="container">
    <div class="logo">💪 IronWill</div>
    <h1>Регистрация</h1>

    <?php if (!empty($errors)): ?>
        <div class="error-box"><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success-box"><?= $success ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <label>Логин</label>
        <input type="text" name="login" value="<?= htmlspecialchars($login) ?>" required minlength="3" pattern="[a-zA-Z0-9_]+">

        <label>Пароль</label>
        <input type="password" name="password" required minlength="6">

        <label>Подтверждение пароля</label>
        <input type="password" name="confirm_password" required minlength="6">

        <label>Имя</label>
        <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required minlength="2">

        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

        <button type="submit">Зарегистрироваться</button>
    </form>

    <div class="links">
        Уже есть аккаунт? <a href="login.php">Войти</a>
    </div>
</div>
</body>
</html>