<?php
if (!isset($pageTitle)) $pageTitle = 'IronWill';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> — IronWill</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #1a1a2e; color: #eee; min-height: 100vh; }
        .topbar { background: #0f3460; padding: 12px 20px; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; }
        .topbar .logo { font-size: 22px; font-weight: bold; color: #f39c12; }
        .topbar nav { display: flex; gap: 16px; flex-wrap: wrap; }
        .topbar nav a { color: #ccc; text-decoration: none; font-size: 14px; transition: color 0.2s; }
        .topbar nav a:hover, .topbar nav a.active { color: #f39c12; }
        .topbar .user-info { font-size: 13px; color: #aaa; }
        .container { max-width: 900px; margin: 20px auto; padding: 0 16px; }
        .success-box { background: #27ae60; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }
        .error-box { background: #c0392b; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }
        footer { text-align: center; padding: 20px; color: #555; font-size: 12px; margin-top: 40px; border-top: 1px solid #0f3460; }
    </style>
</head>
<body>
<div class="topbar">
    <div class="logo">💪 IronWill</div>
    <nav>
        <a href="index.php" class="<?= basename($_SERVER['PHP_SELF'] ?? '') == 'index.php' ? 'active' : '' ?>">Главная</a>
        <a href="workouts.php" class="<?= basename($_SERVER['PHP_SELF'] ?? '') == 'workouts.php' ? 'active' : '' ?>">Расписание</a>
        <a href="my_bookings.php" class="<?= basename($_SERVER['PHP_SELF'] ?? '') == 'my_bookings.php' ? 'active' : '' ?>">Мои записи</a>
        <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'] ?? '') == 'settings.php' ? 'active' : '' ?>">Настройки</a>
        <a href="logout.php">Выход</a>
    </nav>
    <div class="user-info">👤 <?= htmlspecialchars($_SESSION['user_name'] ?? 'Пользователь') ?></div>
</div>
<div class="container">