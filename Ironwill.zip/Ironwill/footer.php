</div><!-- .container -->
<footer>
    &copy; <?= date('Y') ?> IronWill Fitness Club. Все права защищены.
</footer>
</body>
</html>