<?php
require_once 'functions.php';
requireAuth();

$pageTitle = 'Мои записи';
require_once 'header.php';

$user_login = $_SESSION['user_login'];
$bookings = getBookingsByUser($user_login);

// Проверка сообщения из cancel_booking.php
$message = '';
$messageType = '';
if (isset($_GET['cancelled'])) {
    $message = 'Запись успешно отменена.';
    $messageType = 'success';
}
if (isset($_GET['error'])) {
    $message = 'Ошибка при отмене записи.';
    $messageType = 'error';
}
?>

<h1>📌 Мои записи на тренировки</h1>

<?php if ($message): ?>
    <div class="<?= $messageType === 'success' ? 'success-box' : 'error-box' ?>">
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<?php if (empty($bookings)): ?>
    <p style="margin-top:20px;color:#aaa;">У вас пока нет записей на тренировки. <a href="workouts.php" style="color:#f39c12;">Перейти к расписанию</a></p>
<?php else: ?>
    <div style="margin-top:20px;display:grid;gap:16px;">
        <?php foreach ($bookings as $b): ?>
            <?php $w = $b['workout']; ?>
            <div style="background:#16213e;padding:16px 20px;border-radius:10px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
                <div>
                    <h3 style="color:#f39c12;"><?= htmlspecialchars($w['title'] ?? 'Тренировка удалена') ?></h3>
                    <?php if ($w): ?>
                        <p style="font-size:13px;color:#aaa;"><?= htmlspecialchars($w['description']) ?></p>
                        <p style="font-size:13px;margin-top:4px;">
                            📅 <?= htmlspecialchars($w['datetime']) ?> &nbsp;|&nbsp;
                            🏷️ <?= $w['type'] === 'group' ? 'Групповая' : 'Персональная' ?>
                        </p>
                    <?php endif; ?>
                    <p style="font-size:11px;color:#555;margin-top:4px;">Записано: <?= htmlspecialchars($b['booking_date']) ?></p>
                </div>
                <button onclick="if(confirm('Вы уверены, что хотите отменить запись на эту тренировку?')){window.location.href='cancel_booking.php?id=<?= $b['id'] ?>';}" 
                        style="background:#c0392b;color:#fff;border:none;padding:10px 18px;border-radius:6px;font-weight:bold;cursor:pointer;">
                    ❌ Отменить
                </button>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once 'footer.php'; ?>