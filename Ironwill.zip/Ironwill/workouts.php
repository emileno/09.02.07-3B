<?php
require_once 'functions.php';
requireAuth();

$pageTitle = 'Расписание тренировок';
require_once 'header.php';

$message = '';
$messageType = '';

// Обработка записи на тренировку
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_workout_id'])) {
    $workout_id = $_POST['book_workout_id'];
    $user_login = $_SESSION['user_login'];

    $workout = getWorkoutById($workout_id);
    if (!$workout) {
        $message = 'Тренировка не найдена.';
        $messageType = 'error';
    } elseif (isUserBooked($user_login, $workout_id)) {
        $message = 'Вы уже записаны на эту тренировку.';
        $messageType = 'error';
    } elseif (getBookingCountForWorkout($workout_id) >= $workout['max_participants']) {
        $message = 'К сожалению, все места на эту тренировку заняты.';
        $messageType = 'error';
    } else {
        createBooking($user_login, $workout_id);
        $message = 'Вы успешно записаны на тренировку «' . htmlspecialchars($workout['title']) . '»!';
        $messageType = 'success';
    }
}

$workouts = getAllWorkouts();
// Сортировка по дате
usort($workouts, function($a, $b) {
    return strtotime($a['datetime']) - strtotime($b['datetime']);
});
?>

<h1>📋 Расписание тренировок</h1>

<?php if ($message): ?>
    <div class="<?= $messageType === 'success' ? 'success-box' : 'error-box' ?>">
        <?= $message ?>
    </div>
<?php endif; ?>

<?php if (empty($workouts)): ?>
    <p style="margin-top:20px;color:#aaa;">Пока нет доступных тренировок.</p>
<?php else: ?>
    <div style="margin-top:20px;display:grid;gap:16px;">
        <?php foreach ($workouts as $w): 
            $bookedCount = getBookingCountForWorkout($w['id']);
            $alreadyBooked = isUserBooked($_SESSION['user_login'], $w['id']);
            $isFull = $bookedCount >= $w['max_participants'];
        ?>
            <div style="background:#16213e;padding:16px 20px;border-radius:10px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
                <div>
                    <h3 style="color:#f39c12;"><?= htmlspecialchars($w['title']) ?></h3>
                    <p style="font-size:13px;color:#aaa;"><?= htmlspecialchars($w['description']) ?></p>
                    <p style="font-size:13px;margin-top:4px;">
                        📅 <?= htmlspecialchars($w['datetime']) ?> &nbsp;|&nbsp;
                        🏷️ <?= $w['type'] === 'group' ? 'Групповая' : 'Персональная' ?> &nbsp;|&nbsp;
                        👥 <?= $bookedCount ?>/<?= $w['max_participants'] ?>
                    </p>
                </div>
                <form method="post" style="margin:0;">
                    <input type="hidden" name="book_workout_id" value="<?= $w['id'] ?>">
                    <?php if ($alreadyBooked): ?>
                        <span style="color:#27ae60;font-weight:bold;">✅ Вы записаны</span>
                    <?php elseif ($isFull): ?>
                        <span style="color:#c0392b;">❌ Мест нет</span>
                    <?php else: ?>
                        <button type="submit" style="background:#f39c12;color:#1a1a2e;border:none;padding:10px 18px;border-radius:6px;font-weight:bold;cursor:pointer;">Записаться</button>
                    <?php endif; ?>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once 'footer.php'; ?>