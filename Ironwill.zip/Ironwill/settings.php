<?php
require_once 'functions.php';
requireAuth();

$pageTitle = 'Настройки профиля';
require_once 'header.php';

$user = getCurrentUser();
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $new_name = trim($_POST['name'] ?? '');
        $new_email = trim($_POST['email'] ?? '');

        $error = validateName($new_name);
        if ($error) $errors[] = $error;
        $error = validateEmail($new_email);
        if ($error) $errors[] = $error;

        if (empty($errors)) {
            updateUser($user['login'], [
                'name' => $new_name,
                'email' => $new_email
            ]);
            $_SESSION['user_name'] = $new_name;
            $_SESSION['user_email'] = $new_email;
            $user = getCurrentUser(); // обновить данные
            $success = 'Профиль успешно обновлён!';
        }
    } elseif ($action === 'change_password') {
        $old_password = $_POST['old_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_new = $_POST['confirm_new'] ?? '';

        if (!password_verify($old_password, $user['password'])) {
            $errors[] = 'Неверный текущий пароль';
        }
        $error = validatePassword($new_password);
        if ($error) $errors[] = $error;
        if ($new_password !== $confirm_new) $errors[] = 'Новые пароли не совпадают';

        if (empty($errors)) {
            $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
            updateUser($user['login'], [
                'password' => $new_hash
            ]);
            $success = 'Пароль успешно изменён!';
        }
    }
}
?>

<h1>⚙️ Настройки профиля</h1>

<?php if (!empty($errors)): ?>
    <div class="error-box"><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="success-box"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<div style="display:grid;gap:28px;margin-top:20px;">

    <!-- Смена имени и email -->
    <div style="background:#16213e;padding:20px;border-radius:10px;">
        <h3 style="color:#f39c12;margin-bottom:14px;">👤 Личные данные</h3>
        <form method="post">
            <input type="hidden" name="action" value="update_profile">
            <label style="display:block;font-weight:600;">Имя</label>
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required minlength="2" style="width:100%;padding:10px;margin-top:4px;border:none;border-radius:6px;background:#0f3460;color:#fff;">
            <label style="display:block;margin-top:14px;font-weight:600;">Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required style="width:100%;padding:10px;margin-top:4px;border:none;border-radius:6px;background:#0f3460;color:#fff;">
            <button type="submit" style="margin-top:16px;background:#f39c12;color:#1a1a2e;border:none;padding:10px 24px;border-radius:6px;font-weight:bold;cursor:pointer;">Сохранить</button>
        </form>
    </div>

    <!-- Смена пароля -->
    <div style="background:#16213e;padding:20px;border-radius:10px;">
        <h3 style="color:#f39c12;margin-bottom:14px;">🔒 Смена пароля</h3>
        <form method="post">
            <input type="hidden" name="action" value="change_password">
            <label style="display:block;font-weight:600;">Текущий пароль</label>
            <input type="password" name="old_password" required style="width:100%;padding:10px;margin-top:4px;border:none;border-radius:6px;background:#0f3460;color:#fff;">
            <label style="display:block;margin-top:14px;font-weight:600;">Новый пароль</label>
            <input type="password" name="new_password" required minlength="6" style="width:100%;padding:10px;margin-top:4px;border:none;border-radius:6px;background:#0f3460;color:#fff;">
            <label style="display:block;margin-top:14px;font-weight:600;">Подтверждение нового пароля</label>
            <input type="password" name="confirm_new" required minlength="6" style="width:100%;padding:10px;margin-top:4px;border:none;border-radius:6px;background:#0f3460;color:#fff;">
            <button type="submit" style="margin-top:16px;background:#f39c12;color:#1a1a2e;border:none;padding:10px 24px;border-radius:6px;font-weight:bold;cursor:pointer;">Сменить пароль</button>
        </form>
    </div>

</div>

<?php require_once 'footer.php'; ?>