<?php
require_once 'functions.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    if (empty($login) || empty($password)) {
        $error = 'Заполните все поля';
    } else {
        if (loginUser($login, $password, $remember)) {
            header('Location: index.php');
            exit();
        } else {
            $error = 'Неверный логин или пароль';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IronWill — Вход</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #1a1a2e; color: #eee; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .container { background: #16213e; padding: 30px; border-radius: 12px; width: 100%; max-width: 420px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); }
        h1 { text-align: center; color: #f39c12; margin-bottom: 20px; }
        .logo { font-size: 28px; font-weight: bold; text-align: center; margin-bottom: 10px; }
        label { display: block; margin-top: 14px; font-weight: 600; }
        input[type="text"], input[type="password"] { width: 100%; padding: 12px; margin-top: 4px; border: none; border-radius: 6px; background: #0f3460; color: #fff; font-size: 14px; }
        button { width: 100%; padding: 12px; margin-top: 20px; background: #f39c12; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; color: #1a1a2e; cursor: pointer; }
        button:hover { background: #e67e22; }
        .error-box { background: #c0392b; padding: 10px; border-radius: 6px; margin-top: 14px; font-size: 13px; }
        .checkbox-row { margin-top: 14px; display: flex; align-items: center; gap: 8px; font-size: 13px; }
        a { color: #f39c12; }
        .links { text-align: center; margin-top: 16px; font-size: 13px; }
    </style>
</head>
<body>
<div class="container">
    <div class="logo">💪 IronWill</div>
    <h1>Вход</h1>

    <?php if ($error): ?>
        <div class="error-box"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <label>Логин</label>
        <input type="text" name="login" required>

        <label>Пароль</label>
        <input type="password" name="password" required>

        <div class="checkbox-row">
            <input type="checkbox" name="remember" id="remember">
            <label for="remember" style="margin-top:0;">Запомнить меня</label>
        </div>

        <button type="submit">Войти</button>
    </form>

    <div class="links">
        Нет аккаунта? <a href="register.php">Зарегистрироваться</a>
    </div>
</div>
</body>
</html>