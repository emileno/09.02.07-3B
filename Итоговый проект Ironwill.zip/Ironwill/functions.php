<?php
session_start();

// ==================== ДИРЕКТОРИЯ ====================
function ensureDataDir() {
    if (!is_dir('data')) {
        mkdir('data', 0777, true);
    }
}

// ==================== ПОЛЬЗОВАТЕЛИ ====================
function getAllUsers() {
    ensureDataDir();
    $file = 'data/users.txt';
    if (!file_exists($file)) return [];
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $users = [];
    foreach ($lines as $line) {
        $user = explode('|', $line);
        if (count($user) >= 5) {
            $users[] = [
                'login' => $user[0],
                'password' => $user[1],
                'name' => $user[2],
                'email' => $user[3],
                'reg_date' => $user[4]
            ];
        }
    }
    return $users;
}

function findUserByLogin($login) {
    foreach (getAllUsers() as $user) {
        if ($user['login'] === $login) return $user;
    }
    return null;
}

function saveUser($user) {
    ensureDataDir();
    $line = implode('|', [
        $user['login'],
        $user['password'],
        $user['name'],
        $user['email'],
        $user['reg_date'] ?? date('Y-m-d H:i:s')
    ]) . PHP_EOL;
    file_put_contents('data/users.txt', $line, FILE_APPEND | LOCK_EX);
    return true;
}

function updateUser($login, $newData) {
    $users = getAllUsers();
    $newLines = [];
    $found = false;
    foreach ($users as $user) {
        if ($user['login'] === $login) {
            $user = array_merge($user, $newData);
            $found = true;
        }
        $newLines[] = implode('|', [
            $user['login'],
            $user['password'],
            $user['name'],
            $user['email'],
            $user['reg_date']
        ]);
    }
    if ($found) {
        file_put_contents('data/users.txt', implode(PHP_EOL, $newLines) . PHP_EOL);
        return true;
    }
    return false;
}

// ==================== ТРЕНИРОВКИ ====================
function getAllWorkouts() {
    ensureDataDir();
    $file = 'data/workouts.txt';
    if (!file_exists($file)) return [];
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $workouts = [];
    foreach ($lines as $line) {
        $w = explode('|', $line);
        if (count($w) >= 7) {
            $workouts[] = [
                'id' => $w[0],
                'type' => $w[1],
                'title' => $w[2],
                'description' => $w[3],
                'datetime' => $w[4],
                'max_participants' => $w[5],
                'created_by' => $w[6]
            ];
        }
    }
    return $workouts;
}

function getWorkoutById($id) {
    foreach (getAllWorkouts() as $w) {
        if ($w['id'] == $id) return $w;
    }
    return null;
}

function getNextWorkoutId() {
    $workouts = getAllWorkouts();
    $maxId = 0;
    foreach ($workouts as $w) {
        if ($w['id'] > $maxId) $maxId = $w['id'];
    }
    return $maxId + 1;
}

function saveWorkout($data) {
    ensureDataDir();
    $line = implode('|', [
        $data['id'],
        $data['type'],
        $data['title'],
        $data['description'],
        $data['datetime'],
        $data['max_participants'],
        $data['created_by']
    ]) . PHP_EOL;
    file_put_contents('data/workouts.txt', $line, FILE_APPEND | LOCK_EX);
    return true;
}

// ==================== ЗАПИСИ НА ТРЕНИРОВКИ ====================
function getAllBookings() {
    ensureDataDir();
    $file = 'data/bookings.txt';
    if (!file_exists($file)) return [];
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $bookings = [];
    foreach ($lines as $line) {
        $b = explode('|', $line);
        if (count($b) >= 4) {
            $bookings[] = [
                'id' => $b[0],
                'workout_id' => $b[1],
                'user_login' => $b[2],
                'booking_date' => $b[3]
            ];
        }
    }
    return $bookings;
}

function getBookingsByUser($user_login) {
    $result = [];
    foreach (getAllBookings() as $b) {
        if ($b['user_login'] === $user_login) {
            $b['workout'] = getWorkoutById($b['workout_id']);
            $result[] = $b;
        }
    }
    // Сортировка по дате тренировки (ближайшие сверху)
    usort($result, function($a, $b) {
        return strtotime($a['workout']['datetime'] ?? '') - strtotime($b['workout']['datetime'] ?? '');
    });
    return $result;
}

function getBookingById($id, $user_login) {
    foreach (getAllBookings() as $b) {
        if ($b['id'] == $id && $b['user_login'] === $user_login) {
            $b['workout'] = getWorkoutById($b['workout_id']);
            return $b;
        }
    }
    return null;
}

function getNextBookingId() {
    $bookings = getAllBookings();
    $maxId = 0;
    foreach ($bookings as $b) {
        if ($b['id'] > $maxId) $maxId = $b['id'];
    }
    return $maxId + 1;
}

function createBooking($user_login, $workout_id) {
    ensureDataDir();
    $id = getNextBookingId();
    $line = implode('|', [$id, $workout_id, $user_login, date('Y-m-d H:i:s')]) . PHP_EOL;
    file_put_contents('data/bookings.txt', $line, FILE_APPEND | LOCK_EX);
    return true;
}

function deleteBooking($id, $user_login) {
    $bookings = getAllBookings();
    $newLines = [];
    $found = false;
    foreach ($bookings as $b) {
        if ($b['id'] == $id && $b['user_login'] === $user_login) {
            $found = true;
            continue;
        }
        $newLines[] = implode('|', [$b['id'], $b['workout_id'], $b['user_login'], $b['booking_date']]);
    }
    if ($found) {
        file_put_contents('data/bookings.txt', implode(PHP_EOL, $newLines) . PHP_EOL);
        return true;
    }
    return false;
}

function isUserBooked($user_login, $workout_id) {
    foreach (getAllBookings() as $b) {
        if ($b['user_login'] === $user_login && $b['workout_id'] == $workout_id) return true;
    }
    return false;
}

function getBookingCountForWorkout($workout_id) {
    $count = 0;
    foreach (getAllBookings() as $b) {
        if ($b['workout_id'] == $workout_id) $count++;
    }
    return $count;
}

// ==================== ВАЛИДАЦИЯ ====================
function validateLogin($login) {
    if (strlen($login) < 3) return 'Логин должен быть не менее 3 символов';
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) return 'Логин может содержать только буквы, цифры и _';
    return '';
}

function validatePassword($password) {
    if (strlen($password) < 6) return 'Пароль должен быть не менее 6 символов';
    return '';
}

function validateName($name) {
    if (strlen($name) < 2) return 'Имя должно быть не менее 2 символов';
    if (!preg_match('/^[a-zA-Zа-яА-ЯёЁ\s\-]+$/u', $name)) return 'Имя может содержать только буквы, пробелы и дефис';
    return '';
}

function validateEmail($email) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return 'Некорректный email';
    return '';
}

function validateWorkoutType($type) {
    if (!in_array($type, ['group', 'personal'])) return 'Тип тренировки должен быть "group" или "personal"';
    return '';
}

function validateWorkoutTitle($title) {
    if (strlen($title) < 3) return 'Название тренировки должно быть не менее 3 символов';
    return '';
}

// ==================== АУТЕНТИФИКАЦИЯ ====================
function registerUser($login, $password, $name, $email) {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    return saveUser([
        'login' => $login,
        'password' => $hash,
        'name' => $name,
        'email' => $email,
        'reg_date' => date('Y-m-d H:i:s')
    ]);
}

function loginUser($login, $password, $remember = false) {
    $user = findUserByLogin($login);
    if (!$user) return false;
    if (!password_verify($password, $user['password'])) return false;

    $_SESSION['user_login'] = $user['login'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];

    if ($remember) {
        $token = bin2hex(random_bytes(32));
        setcookie('remember_token', $token, time() + 60 * 60 * 24 * 30, '/');
        // В реальном проекте токен нужно сохранять в файл, для учебного упростим
        setcookie('remember_login', $login, time() + 60 * 60 * 24 * 30, '/');
    }

    return true;
}

function logoutUser() {
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    setcookie('remember_login', '', time() - 3600, '/');
}

function isLoggedIn() {
    if (isset($_SESSION['user_login'])) return true;

    // Проверка cookie "Запомнить меня"
    if (isset($_COOKIE['remember_login']) && !isset($_SESSION['user_login'])) {
        $user = findUserByLogin($_COOKIE['remember_login']);
        if ($user) {
            $_SESSION['user_login'] = $user['login'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            return true;
        }
    }

    return false;
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    return findUserByLogin($_SESSION['user_login']);
}

function requireAuth() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// ==================== ИНИЦИАЛИЗАЦИЯ ДАННЫХ ====================
function initSampleWorkouts() {
    if (count(getAllWorkouts()) > 0) return;
    $sampleWorkouts = [
        ['id' => 1, 'type' => 'group', 'title' => 'Йога для начинающих', 'description' => 'Расслабляющая практика для всех уровней подготовки', 'datetime' => '2026-05-10 10:00', 'max_participants' => 15, 'created_by' => 'admin'],
        ['id' => 2, 'type' => 'group', 'title' => 'Силовая тренировка', 'description' => 'Интенсивная работа с весами для роста мышц', 'datetime' => '2026-05-10 12:00', 'max_participants' => 10, 'created_by' => 'admin'],
        ['id' => 3, 'type' => 'personal', 'title' => 'Персональная тренировка с тренером', 'description' => 'Индивидуальная программа под ваш уровень', 'datetime' => '2026-05-11 09:00', 'max_participants' => 1, 'created_by' => 'admin'],
        ['id' => 4, 'type' => 'group', 'title' => 'Кардио-микс', 'description' => 'Аэробная тренировка для сжигания калорий', 'datetime' => '2026-05-11 18:00', 'max_participants' => 20, 'created_by' => 'admin'],
        ['id' => 5, 'type' => 'group', 'title' => 'Растяжка и гибкость', 'description' => 'Улучшение подвижности суставов и эластичности мышц', 'datetime' => '2026-05-12 11:00', 'max_participants' => 12, 'created_by' => 'admin'],
    ];
    foreach ($sampleWorkouts as $w) {
        saveWorkout($w);
    }
}

// Инициализация при первом запуске
initSampleWorkouts();