<?php
require_once 'functions.php';

// Если пользователь не авторизован, показываем приветственную страницу
if (!isLoggedIn()) {
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>IronWill Fitness Club</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Segoe UI', Tahoma, sans-serif; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #eee; display: flex; justify-content: center; align-items: center; min-height: 100vh; text-align: center; }
            .hero { max-width: 500px; padding: 40px; }
            .hero h1 { font-size: 42px; color: #f39c12; margin-bottom: 12px; }
            .hero p { font-size: 16px; color: #aaa; margin-bottom: 28px; line-height: 1.6; }
            .hero .btn { display: inline-block; padding: 14px 32px; margin: 6px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 15px; }
            .btn-primary { background: #f39c12; color: #1a1a2e; }
            .btn-secondary { background: transparent; color: #f39c12; border: 2px solid #f39c12; }
            .btn:hover { opacity: 0.85; }
        </style>
    </head>
    <body>
    <div class="hero">
        <h1>💪 IronWill</h1>
        <p>Добро пожаловать в фитнес-клуб нового поколения.<br>Записывайтесь на тренировки и достигайте своих целей вместе с нами!</p>
        <a href="login.php" class="btn btn-primary">Войти</a>
        <a href="register.php" class="btn btn-secondary">Регистрация</a>
    </div>
    </body>
    </html>
    <?php
    exit();
}

// Авторизованный пользователь
$pageTitle = 'Главная';
require_once 'header.php';

$user = getCurrentUser();
$bookings = getBookingsByUser($user['login']);
$totalBookings = count($bookings);

// Ищем ближайшую тренировку
$nearestBooking = null;
$now = date('Y-m-d H:i:s');
foreach ($bookings as $b) {
    if (!empty($b['workout']['datetime']) && $b['workout']['datetime'] >= $now) {
        $nearestBooking = $b;
        break;
    }
}
?>

<h1>С возвращением, <?= htmlspecialchars($user['name']) ?>!</h1>
<p style="margin-top:4px;color:#aaa;">Готовы к новым победам? 💥</p>

<div style="display:flex;gap:20px;flex-wrap:wrap;margin-top:24px;">
    <div style="background:#16213e;padding:20px;border-radius:10px;flex:1;min-width:200px;">
        <h3 style="color:#f39c12;">📊 Ваши записи</h3>
        <p style="font-size:36px;font-weight:bold;margin-top:8px;"><?= $totalBookings ?></p>
        <p style="font-size:13px;color:#aaa;">активных записей на тренировки</p>
    </div>
    <div style="background:#16213e;padding:20px;border-radius:10px;flex:2;min-width:280px;">
        <h3 style="color:#f39c12;">⏰ Ближайшая тренировка</h3>
        <?php if ($nearestBooking && $nearestBooking['workout']): ?>
            <p style="font-size:18px;font-weight:bold;margin-top:8px;"><?= htmlspecialchars($nearestBooking['workout']['title']) ?></p>
            <p style="font-size:14px;color:#aaa;">📅 <?= htmlspecialchars($nearestBooking['workout']['datetime']) ?></p>
            <p style="font-size:13px;color:#aaa;">Тип: <?= $nearestBooking['workout']['type'] === 'group' ? 'Групповая' : 'Персональная' ?></p>
        <?php else: ?>
            <p style="margin-top:8px;color:#aaa;">Нет предстоящих тренировок. <a href="workouts.php" style="color:#f39c12;">Записаться</a></p>
        <?php endif; ?>
    </div>
</div>

<div style="margin-top:28px;display:flex;gap:12px;flex-wrap:wrap;">
    <a href="workouts.php" style="background:#f39c12;color:#1a1a2e;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;">📋 Расписание тренировок</a>
    <a href="my_bookings.php" style="background:#0f3460;color:#eee;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;">📌 Мои записи</a>
    <a href="settings.php" style="background:#0f3460;color:#eee;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;">⚙️ Настройки профиля</a>
</div>

<?php require_once 'footer.php'; ?>