<?php
require_once 'functions.php';
checkAuth();

$user_login = $_SESSION['user_login'];
$id = (int)($_GET['id'] ?? 0);

// Проверка владельца заметки
if (checkNoteOwner($user_login, $id)) {
    deleteNote($id, $_SESSION['user_id']);
}

header('Location: notes.php');
exit();
?>