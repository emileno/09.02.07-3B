<?php
require_once 'functions.php';
checkAuth();

$user_login = $_SESSION['user_login'];
$user = getUserByLogin($user_login);
$notes = getUserNotes($user_login);

// Статистика
$total_notes = count($notes);
$today_notes = 0;
$today = date('Y-m-d');
foreach ($notes as $note) {
    if (substr($note['created'], 0, 10) === $today) {
        $today_notes++;
    }
}

// Обработка быстрой формы
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_add'])) {
    $title = trim($_POST['title'] ?? '');
    $text = trim($_POST['text'] ?? '');
    
    if (validateTitle($title)) {
        saveNote($_SESSION['user_id'], $title, $text);
        header('Location: index.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный блокнот - Главная</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="theme-<?= $user['theme'] ?>">
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">📓 Личный блокнот</a>
            <div class="nav-menu">
                <a href="notes.php" class="nav-link">📝 Заметки</a>
                <a href="settings.php" class="nav-link">⚙️ Настройки</a>
                <a href="logout.php" class="nav-link">🚪 Выход</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="welcome-card">
            <h1>Здравствуйте, <?= htmlspecialchars($user['name']) ?>! 👋</h1>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_notes ?></div>
                    <div class="stat-label">Всего заметок</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $today_notes ?></div>
                    <div class="stat-label">Создано сегодня</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">
                        <?php if (!empty($notes)): ?>
                            <?= date('d.m.Y H:i', strtotime($notes[0]['updated'])) ?>
                        <?php else: ?>
                            Нет заметок
                        <?php endif; ?>
                    </div>
                    <div class="stat-label">Последняя активность</div>
                </div>
            </div>
        </div>
        
        <div class="quick-add-card">
            <h2>Быстрая заметка ✍️</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <input type="text" name="title" placeholder="Заголовок" required>
                </div>
                <div class="form-group">
                    <textarea name="text" rows="4" placeholder="Текст заметки..."></textarea>
                </div>
                <button type="submit" name="quick_add" class="btn btn-primary">➕ Добавить</button>
            </form>
        </div>
        
        <div class="quick-links">
            <a href="notes.php" class="quick-link">📋 Все заметки</a>
            <a href="note_add.php" class="quick-link">✏️ Создать заметку</a>
        </div>
    </div>
</body>
</html>