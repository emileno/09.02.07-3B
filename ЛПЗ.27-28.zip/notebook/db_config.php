<?php
// db_config.php - подключение к базе данных
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'notebook_db';

// Создаем подключение
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Проверяем подключение
if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// Устанавливаем кодировку
$conn->set_charset("utf8mb4");
?>