<?php
session_start();
session_destroy();

// Удаление cookie
setcookie('remember_me', '', time() - 3600, '/');
setcookie('user_login', '', time() - 3600, '/');

header('Location: login.php');
exit();
?>