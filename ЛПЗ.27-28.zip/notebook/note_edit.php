<?php
require_once 'functions.php';
checkAuth();

$user_login = $_SESSION['user_login'];
$user = getUserByLogin($user_login);
$id = (int)($_GET['id'] ?? 0);
$error = '';

// Проверка владельца заметки
if (!checkNoteOwner($user_login, $id)) {
    header('Location: notes.php');
    exit();
}

$note = getNoteById($id, $_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $text = trim($_POST['text'] ?? '');
    
    if (!validateTitle($title)) {
        $error = 'Заголовок должен быть от 3 до 100 символов';
    } else {
        if (updateNote($id, $_SESSION['user_id'], $title, $text)) {
            header('Location: notes.php');
            exit();
        } else {
            $error = 'Ошибка при сохранении заметки';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактирование заметки - Личный блокнот</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="theme-<?= $user['theme'] ?>">
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">📓 Личный блокнот</a>
            <div class="nav-menu">
                <a href="notes.php" class="nav-link">📝 Заметки</a>
                <a href="settings.php" class="nav-link">⚙️ Настройки</a>
                <a href="logout.php" class="nav-link">🚪 Выход</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="form-container">
            <h1>Редактирование заметки</h1>
            
            <?php if ($error): ?>
                <?= showMessage($error, 'error') ?>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="title">Заголовок: *</label>
                    <input type="text" id="title" name="title" required 
                           value="<?= htmlspecialchars($note['title']) ?>">
                    <small>3-100 символов</small>
                </div>
                
                <div class="form-group">
                    <label for="text">Текст заметки:</label>
                    <textarea id="text" name="text" rows="10"><?= htmlspecialchars($note['content']) ?></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">💾 Сохранить</button>
                <a href="notes.php" class="btn">Отмена</a>
            </form>
        </div>
    </div>
</body>
</html>
