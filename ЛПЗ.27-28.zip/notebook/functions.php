<?php
session_start();
require_once 'db_config.php';

// Функция для проверки авторизации
function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        if (isset($_COOKIE['remember_me']) && isset($_COOKIE['user_login'])) {
            global $conn;
            $stmt = $conn->prepare("SELECT id, login FROM users WHERE login = ?");
            $stmt->bind_param("s", $_COOKIE['user_login']);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_login'] = $row['login'];
                return true;
            }
        }
        header('Location: login.php');
        exit();
    }
    return true;
}

// Функция для получения пользователя по логину
function getUserByLogin($login) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Функция для получения пользователя по ID
function getUserById($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Функция для получения всех пользователей
function getUsers() {
    global $conn;
    $result = $conn->query("SELECT * FROM users");
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[$row['login']] = $row;
    }
    return $users;
}

// Функция для сохранения пользователей (массовое обновление)
function saveUsers($users) {
    global $conn;
    foreach ($users as $user) {
        $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, theme = ? WHERE login = ?");
        $stmt->bind_param("ssss", $user['name'], $user['email'], $user['theme'], $user['login']);
        $stmt->execute();
    }
}

// Функция для получения всех заметок пользователя
function getUserNotes($login) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT n.*, u.login 
        FROM notes n 
        JOIN users u ON n.user_id = u.id 
        WHERE u.login = ? 
        ORDER BY n.updated_at DESC
    ");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $notes = [];
    while ($row = $result->fetch_assoc()) {
        $notes[] = [
            'id' => $row['id'],
            'title' => $row['title'],
            'text' => $row['content'],
            'created' => $row['created_at'],
            'updated' => $row['updated_at']
        ];
    }
    return $notes;
}

// Функция для получения одной заметки
function getNoteById($id, $user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM notes WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Функция для сохранения новой заметки
function saveNote($user_id, $title, $content) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $title, $content);
    return $stmt->execute();
}

// Функция для обновления заметки
function updateNote($id, $user_id, $title, $content) {
    global $conn;
    $stmt = $conn->prepare("UPDATE notes SET title = ?, content = ?, updated_at = NOW() WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ssii", $title, $content, $id, $user_id);
    return $stmt->execute();
}

// Функция для удаления заметки
function deleteNote($id, $user_id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM notes WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $user_id);
    return $stmt->execute();
}

// Функция для получения ID пользователя по логину
function getUserIdByLogin($login) {
    global $conn;
    $stmt = $conn->prepare("SELECT id FROM users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['id'];
    }
    return null;
}

// Функция для создания нового пользователя
function createUser($login, $password, $name, $email, $theme = 'light') {
    global $conn;
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (login, password, name, email, theme) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $login, $hashed_password, $name, $email, $theme);
    return $stmt->execute();
}

// Функция для проверки логина и пароля
function authenticateUser($login, $password) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, login, password FROM users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            return $user;
        }
    }
    return false;
}

// Функция для отображения сообщений
function showMessage($msg, $type = 'error') {
    $class = $type === 'error' ? 'error' : 'success';
    return "<div class='message $class'>$msg</div>";
}

// Функция для валидации логина
function validateLogin($login) {
    return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $login);
}

// Функция для валидации пароля
function validatePassword($password) {
    return strlen($password) >= 6;
}

// Функция для валидации имени
function validateName($name) {
    return preg_match('/^[a-zA-Zа-яА-Я]{2,50}$/u', $name);
}

// Функция для валидации email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Функция для валидации заголовка
function validateTitle($title) {
    $len = mb_strlen($title);
    return $len >= 3 && $len <= 100;
}

// Функция для проверки владельца заметки
function checkNoteOwner($login, $id) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT n.id FROM notes n 
        JOIN users u ON n.user_id = u.id 
        WHERE u.login = ? AND n.id = ?
    ");
    $stmt->bind_param("si", $login, $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}
?>