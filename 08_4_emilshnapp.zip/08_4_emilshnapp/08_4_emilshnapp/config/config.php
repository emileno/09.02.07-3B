<?php
session_start();

$host = '127.0.0.1';
$db   = 'coffee_portal';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die('Ошибка подключения к базе данных. Проверьте настройки config/config.php.');
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function requireAuth(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . (defined('APP_BASE_URL') ? APP_BASE_URL : '') . '/login');
        exit;
    }
}
