<?php
require_once __DIR__ . '/config/config.php';

// Определяем базовый URL проекта автоматически.
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$baseUrl = $scriptDir;
if (basename($baseUrl) === 'public') {
    $baseUrl = rtrim(str_replace('\\', '/', dirname($baseUrl)), '/');
}
$baseUrl = $baseUrl === '/' ? '' : $baseUrl;

define('APP_BASE_URL', $baseUrl);

define('APP_ROOT', __DIR__);
define('APP_RUNNING', true);

function url(string $path = '/'): string {
    $path = '/' . ltrim($path, '/');
    return APP_BASE_URL . $path;
}

function redirectTo(string $path): never {
    header('Location: ' . url($path));
    exit;
}

function view(string $file, array $data = []): void {
    extract($data, EXTR_SKIP);
    require APP_ROOT . '/views/' . $file . '.php';
}

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
if (APP_BASE_URL !== '' && str_starts_with($path, APP_BASE_URL)) {
    $path = substr($path, strlen(APP_BASE_URL)) ?: '/';
}
$path = '/' . ltrim($path, '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Практическое задание: фиксируем посещение каждой страницы приложения.
// POST-запросы и сам просмотр журнала не добавляем, чтобы журнал не разрастался
// от технических запросов и собственного просмотра.
if ($method === 'GET' && $path !== '/log') {
    $logFile = APP_ROOT . '/storage/log.txt';
    $line = date('Y-m-d H:i:s')
        . ' | path=' . $path
        . ' | user_id=' . ($_SESSION['user_id'] ?? 'guest')
        . ' | ip=' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown')
        . PHP_EOL;
    file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
}

if ($path === '/' || $path === '/index.php') {
    redirectTo(!empty($_SESSION['user_id']) ? '/dashboard' : '/login');
}

if ($path === '/register' && $method === 'GET') {
    view('register', ['errors' => [], 'old' => []]);
    exit;
}

if ($path === '/register' && $method === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $errors = [];

    if ($name === '') $errors[] = 'Введите имя.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Введите корректный email.';
    if (strlen($password) < 6) $errors[] = 'Пароль должен содержать минимум 6 символов.';

    if (!$errors) {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'Пользователь с таким email уже зарегистрирован.';
        } else {
            $stmt = $pdo->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
            redirectTo('/login?registered=1');
        }
    }

    view('register', ['errors' => $errors, 'old' => ['name' => $name, 'email' => $email]]);
    exit;
}

if ($path === '/login' && $method === 'GET') {
    view('login', ['errors' => [], 'registered' => isset($_GET['registered'])]);
    exit;
}

if ($path === '/login' && $method === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $errors = [];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Введите корректный email.';
    if ($password === '') $errors[] = 'Введите пароль.';

    if (!$errors) {
        $stmt = $pdo->prepare('SELECT id, name, email, password FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['user_name'] = $user['name'];
            redirectTo('/dashboard');
        }
        $errors[] = 'Неверный email или пароль.';
    }

    view('login', ['errors' => $errors, 'registered' => false]);
    exit;
}

if ($path === '/logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    redirectTo('/login');
}

if ($path === '/dashboard') {
    requireAuth();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM suppliers WHERE user_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $supplierCount = (int)$stmt->fetchColumn();
    view('dashboard', ['supplierCount' => $supplierCount]);
    exit;
}

if ($path === '/suppliers' && $method === 'GET') {
    requireAuth();
    $stmt = $pdo->prepare('SELECT id, name, contact_person, phone, created_at FROM suppliers WHERE user_id = ? ORDER BY id DESC');
    $stmt->execute([$_SESSION['user_id']]);
    view('suppliers/index', ['suppliers' => $stmt->fetchAll()]);
    exit;
}

if ($path === '/suppliers/create' && $method === 'GET') {
    requireAuth();
    view('suppliers/form', ['supplier' => null, 'errors' => [], 'action' => url('/suppliers/create')]);
    exit;
}

if ($path === '/suppliers/create' && $method === 'POST') {
    requireAuth();
    $name = trim($_POST['name'] ?? '');
    $contact = trim($_POST['contact_person'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $errors = $name === '' ? ['Название компании обязательно.'] : [];

    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO suppliers (name, contact_person, phone, user_id) VALUES (?, ?, ?, ?)');
        $stmt->execute([$name, $contact, $phone, $_SESSION['user_id']]);
        redirectTo('/suppliers');
    }

    view('suppliers/form', [
        'supplier' => ['name' => $name, 'contact_person' => $contact, 'phone' => $phone],
        'errors' => $errors,
        'action' => url('/suppliers/create')
    ]);
    exit;
}

if (preg_match('#^/suppliers/edit/(\d+)$#', $path, $m)) {
    requireAuth();
    $id = (int)$m[1];

    if ($method === 'GET') {
        $stmt = $pdo->prepare('SELECT * FROM suppliers WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $_SESSION['user_id']]);
        $supplier = $stmt->fetch();
        if (!$supplier) { http_response_code(404); exit('Поставщик не найден.'); }
        view('suppliers/form', ['supplier' => $supplier, 'errors' => [], 'action' => url("/suppliers/edit/$id")]);
        exit;
    }

    if ($method === 'POST') {
        $name = trim($_POST['name'] ?? '');
        $contact = trim($_POST['contact_person'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $errors = $name === '' ? ['Название компании обязательно.'] : [];

        if (!$errors) {
            $stmt = $pdo->prepare('UPDATE suppliers SET name = ?, contact_person = ?, phone = ? WHERE id = ? AND user_id = ?');
            $stmt->execute([$name, $contact, $phone, $id, $_SESSION['user_id']]);
            redirectTo('/suppliers');
        }

        view('suppliers/form', [
            'supplier' => ['id' => $id, 'name' => $name, 'contact_person' => $contact, 'phone' => $phone],
            'errors' => $errors,
            'action' => url("/suppliers/edit/$id")
        ]);
        exit;
    }
}

if (preg_match('#^/suppliers/delete/(\d+)$#', $path, $m) && $method === 'POST') {
    requireAuth();
    $stmt = $pdo->prepare('DELETE FROM suppliers WHERE id = ? AND user_id = ?');
    $stmt->execute([(int)$m[1], $_SESSION['user_id']]);
    redirectTo('/suppliers');
}

if ($path === '/files' && $method === 'GET') {
    requireAuth();
    $uploadDir = APP_ROOT . '/uploads';
    $files = is_dir($uploadDir) ? array_values(array_filter(scandir($uploadDir), fn($f) => $f !== '.' && $f !== '..' && is_file($uploadDir . DIRECTORY_SEPARATOR . $f))) : [];
    view('files', ['files' => $files]);
    exit;
}

if ($path === '/editor' && $method === 'GET') {
    requireAuth();
    $file = APP_ROOT . '/storage/text.txt';
    $text = file_exists($file) ? (string)file_get_contents($file) : '';
    view('editor', ['editorText' => $text, 'saved' => isset($_GET['saved'])]);
    exit;
}

if ($path === '/editor' && $method === 'POST') {
    requireAuth();
    $text = $_POST['content'] ?? '';
    file_put_contents(APP_ROOT . '/storage/text.txt', $text, LOCK_EX);
    redirectTo('/editor?saved=1');
}

if ($path === '/log' && $method === 'GET') {
    requireAuth();
    $logFile = APP_ROOT . '/storage/log.txt';
    $message = file_exists($logFile) ? (string)file_get_contents($logFile) : 'Журнал пока пуст.';
    view('log', ['message' => $message]);
    exit;
}

http_response_code(404);
view('404', []);
