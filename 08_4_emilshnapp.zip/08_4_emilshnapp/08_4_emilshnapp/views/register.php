<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Регистрация'; ob_start(); ?>
<div class="auth-layout">
  <div class="auth-intro">
    <div>
      <a class="brand" href="<?= e(url('/login')) ?>"><span class="brand-mark">К</span><span>Кофеин</span></a>
      <h1>Создайте<br>рабочее<br>пространство.</h1>
      <p>После регистрации вы сможете вести собственный список поставщиков и пользоваться инструментами портала.</p>
    </div>
    <div class="auth-points">
      <div class="auth-point"><i>01</i><span>Заполните имя и email</span></div>
      <div class="auth-point"><i>02</i><span>Создайте пароль от 6 символов</span></div>
      <div class="auth-point"><i>03</i><span>Начните добавлять поставщиков</span></div>
    </div>
  </div>
  <div class="auth-form"><div class="auth-form-inner">
    <div class="auth-logo">К</div>
    <h1 class="auth-title">Новый аккаунт</h1>
    <p class="auth-copy">Это займёт меньше минуты.</p>
    <?php foreach (($errors ?? []) as $error): ?><div class="alert alert-danger mb-3"><?= e($error) ?></div><?php endforeach; ?>
    <form method="post" action="<?= e(url('/register')) ?>" data-validate>
      <div class="mb-3"><label class="form-label">Имя</label><input class="form-control" name="name" placeholder="Ваше имя" required value="<?= e($old['name'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email" placeholder="you@example.com" required value="<?= e($old['email'] ?? '') ?>"></div>
      <div class="mb-4"><label class="form-label">Пароль</label><input class="form-control" type="password" name="password" minlength="6" placeholder="Минимум 6 символов" required></div>
      <button class="btn btn-primary w-100">Создать аккаунт</button>
    </form>
    <p class="text-secondary mt-4 mb-0" style="font-size:.8rem">Уже зарегистрированы? <a href="<?= e(url('/login')) ?>" class="fw-bold text-decoration-none">Войти</a></p>
  </div></div>
</div>
<?php $content=ob_get_clean(); include __DIR__.'/layout.php'; ?>