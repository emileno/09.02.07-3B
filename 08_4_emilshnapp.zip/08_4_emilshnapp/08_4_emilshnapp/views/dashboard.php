<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Обзор'; ob_start(); ?>
<div class="page-header">
  <div>
    <div class="page-kicker">Рабочая область</div>
    <h1 class="page-title">Добро пожаловать, <?= e($_SESSION['user_name']) ?></h1>
    <p class="page-subtitle">Управляйте поставщиками и рабочими файлами из одного места.</p>
  </div>
  <a class="btn btn-primary" href="<?= e(url('/suppliers/create')) ?>">+ Добавить поставщика</a>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-5">
    <div class="card stat-card h-100">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <div class="stat-label">Всего поставщиков</div>
          <div class="stat-number"><?= $supplierCount ?></div>
          <a class="stat-link" href="<?= e(url('/suppliers')) ?>">Открыть список →</a>
        </div>
        <div class="stat-icon">◫</div>
      </div>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-body">
        <div class="stat-label mb-1">Быстрый доступ</div>
        <h2 class="h5 fw-bold mb-3">Инструменты проекта</h2>
        <div class="quick-grid">
          <a class="quick-link" href="<?= e(url('/suppliers')) ?>"><b>Поставщики</b><span>Список и управление</span></a>
          <a class="quick-link" href="<?= e(url('/files')) ?>"><b>Файлы</b><span>Папка uploads</span></a>
          <a class="quick-link" href="<?= e(url('/editor')) ?>"><b>Редактор</b><span>Текстовый файл</span></a>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center">
      <div><div class="stat-label">Система</div><div class="fw-bold mt-1">Все основные разделы доступны из бокового меню</div></div>
      <a class="btn btn-outline-primary btn-sm" href="<?= e(url('/log')) ?>">Открыть журнал</a>
    </div>
  </div>
</div>
<?php $content=ob_get_clean(); include __DIR__.'/layout.php'; ?>