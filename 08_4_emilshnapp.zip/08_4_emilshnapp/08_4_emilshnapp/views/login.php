<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Вход'; ob_start(); ?>
<div class="auth-layout">
  <div class="auth-intro">
    <div>
      <a class="brand" href="<?= e(url('/login')) ?>"><span class="brand-mark">К</span><span>Кофеин</span></a>
      <h1>Управление<br>поставщиками<br>без лишнего.</h1>
      <p>Минималистичная рабочая среда для поставщиков, файлов и внутренних инструментов проекта.</p>
    </div>
    <div class="auth-points">
      <div class="auth-point"><i>✓</i><span>Единый список поставщиков</span></div>
      <div class="auth-point"><i>✓</i><span>Быстрый доступ к рабочим файлам</span></div>
      <div class="auth-point"><i>✓</i><span>Простой текстовый редактор</span></div>
    </div>
  </div>
  <div class="auth-form"><div class="auth-form-inner">
    <div class="auth-logo">К</div>
    <h1 class="auth-title">С возвращением</h1>
    <p class="auth-copy">Введите данные, чтобы продолжить работу.</p>
    <?php if (!empty($registered)): ?><div class="alert alert-success mb-3">Регистрация прошла успешно. Войдите в аккаунт.</div><?php endif; ?>
    <?php foreach (($errors ?? []) as $error): ?><div class="alert alert-danger mb-3"><?= e($error) ?></div><?php endforeach; ?>
    <form method="post" action="<?= e(url('/login')) ?>" data-validate>
      <div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email" placeholder="you@example.com" required></div>
      <div class="mb-4"><label class="form-label">Пароль</label><input class="form-control" type="password" name="password" placeholder="Введите пароль" required></div>
      <button class="btn btn-primary w-100">Войти в систему</button>
    </form>
    <p class="text-secondary mt-4 mb-0" style="font-size:.8rem">Нет аккаунта? <a href="<?= e(url('/register')) ?>" class="fw-bold text-decoration-none">Зарегистрироваться</a></p>
  </div></div>
</div>
<?php $content=ob_get_clean(); include __DIR__.'/layout.php'; ?>