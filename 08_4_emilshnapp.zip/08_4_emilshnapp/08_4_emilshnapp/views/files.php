<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Файлы'; ob_start(); ?>
<div class="page-header">
  <div><div class="page-kicker">Хранилище</div><h1 class="page-title">Файлы</h1><p class="page-subtitle">Содержимое папки uploads.</p></div>
</div>
<div class="card">
  <div class="toolbar"><div><div class="toolbar-title">Файловое хранилище</div><div class="toolbar-meta"><?= count($files) ?> файлов</div></div></div>
  <?php if (!empty($files)): ?>
    <?php foreach ($files as $file): ?><div class="file-row"><div class="file-icon">FILE</div><div><div class="file-name"><?= e($file) ?></div><div class="file-meta">Файл в uploads</div></div></div><?php endforeach; ?>
  <?php else: ?><div class="empty-state"><div class="empty-icon">□</div><div class="fw-bold mb-1">Папка пуста</div><div class="small">В uploads пока нет файлов.</div></div><?php endif; ?>
</div>
<?php $content=ob_get_clean(); include __DIR__.'/layout.php'; ?>