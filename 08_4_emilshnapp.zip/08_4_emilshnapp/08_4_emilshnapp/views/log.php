<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Журнал'; ob_start(); ?>
<div class="page-header">
  <div><div class="page-kicker">Система</div><h1 class="page-title">Журнал посещений</h1><p class="page-subtitle">Технические записи о GET-запросах приложения.</p></div>
</div>
<div class="card"><div class="card-body"><pre class="log-view"><?= e($message) ?></pre></div></div>
<?php $content=ob_get_clean(); include __DIR__.'/layout.php'; ?>