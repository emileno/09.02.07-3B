<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php
$title = $title ?? 'Кофеин';
$isAuth = empty($_SESSION['user_id']);
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?= e(url('/style.css')) ?>">
</head>
<body>
<?php if ($isAuth): ?>
  <div class="auth-page"><?= $content ?></div>
<?php else: ?>
  <div class="app-shell">
    <aside class="app-sidebar">
      <a class="brand" href="<?= e(url('/dashboard')) ?>">
        <span class="brand-mark">К</span><span>Кофеин</span>
      </a>
      <div class="sidebar-label">Рабочая область</div>
      <nav class="sidebar-nav">
        <a class="sidebar-link <?= str_contains($currentPath,'/dashboard') ? 'active' : '' ?>" href="<?= e(url('/dashboard')) ?>"><span class="sidebar-icon">⌂</span>Обзор</a>
        <a class="sidebar-link <?= str_contains($currentPath,'/suppliers') ? 'active' : '' ?>" href="<?= e(url('/suppliers')) ?>"><span class="sidebar-icon">◫</span>Поставщики</a>
        <a class="sidebar-link <?= str_contains($currentPath,'/files') ? 'active' : '' ?>" href="<?= e(url('/files')) ?>"><span class="sidebar-icon">□</span>Файлы</a>
      </nav>
      <div class="sidebar-label">Инструменты</div>
      <nav class="sidebar-nav">
        <a class="sidebar-link <?= str_contains($currentPath,'/editor') ? 'active' : '' ?>" href="<?= e(url('/editor')) ?>"><span class="sidebar-icon">✎</span>Редактор</a>
        <a class="sidebar-link <?= str_contains($currentPath,'/log') ? 'active' : '' ?>" href="<?= e(url('/log')) ?>"><span class="sidebar-icon">≡</span>Журнал</a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-mini">
          <div class="user-avatar"><?= e(mb_strtoupper(mb_substr($_SESSION['user_name'] ?? 'U', 0, 1))) ?></div>
          <div><strong><?= e($_SESSION['user_name'] ?? 'Пользователь') ?></strong><span>Авторизованный пользователь</span></div>
        </div>
        <a class="sidebar-link" href="<?= e(url('/logout')) ?>"><span class="sidebar-icon">↪</span>Выйти</a>
      </div>
    </aside>
    <section class="app-main">
      <header class="app-topbar">
        <div>
          <div class="breadcrumb-mini">Портал управления</div>
          <div class="topbar-title"><?= e($title) ?></div>
        </div>
        <div class="topbar-action">
          <a class="btn btn-primary btn-sm" href="<?= e(url('/suppliers/create')) ?>">+ Поставщик</a>
        </div>
      </header>
      <main class="content"><?= $content ?></main>
      <div class="footer-note">Учебный портал управления поставщиками · ПП.08</div>
    </section>
  </div>
<?php endif; ?>
<script>
document.querySelectorAll('form[data-validate]').forEach(form => form.addEventListener('submit', event => {
  const name = form.querySelector('[name="name"]');
  if (name && !name.value.trim()) {
    event.preventDefault(); alert('Название компании обязательно.'); name.focus(); return;
  }
  const email = form.querySelector('[name="email"]');
  if (email && !email.checkValidity()) {
    event.preventDefault(); alert('Введите корректный email.'); email.focus();
  }
}));
</script>
</body>
</html>