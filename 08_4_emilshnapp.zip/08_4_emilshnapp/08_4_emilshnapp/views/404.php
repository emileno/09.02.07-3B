<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Страница не найдена'; ob_start(); ?>
<div class="card"><div class="empty-state">
  <div style="font-size:4rem;font-weight:800;letter-spacing:-.08em;color:#111827">404</div>
  <h1 class="h4 fw-bold">Такой страницы нет</h1>
  <p class="mb-4">Возможно, адрес был изменён или страница больше не существует.</p>
  <a class="btn btn-primary" href="<?= e(url('/dashboard')) ?>">Вернуться в обзор</a>
</div></div>
<?php $content=ob_get_clean(); include __DIR__.'/layout.php'; ?>