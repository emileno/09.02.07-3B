<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Поставщики'; ob_start(); ?>
<div class="page-header">
  <div><div class="page-kicker">Данные</div><h1 class="page-title">Поставщики</h1><p class="page-subtitle">Компании и контактные лица вашей рабочей области.</p></div>
  <a class="btn btn-primary" href="<?= e(url('/suppliers/create')) ?>">+ Добавить</a>
</div>
<div class="card">
  <div class="toolbar"><div><div class="toolbar-title">Список поставщиков</div><div class="toolbar-meta"><?= count($suppliers) ?> записей</div></div></div>
  <?php if($suppliers): ?>
  <div class="table-responsive"><table class="table">
    <thead><tr><th>ID</th><th>Компания</th><th>Контактное лицо</th><th>Телефон</th><th class="text-end">Действия</th></tr></thead>
    <tbody>
    <?php foreach($suppliers as $s): ?>
      <tr>
        <td data-label="ID"><span class="badge-id"><?=e((string)$s['id'])?></span></td>
        <td data-label="Компания"><span class="table-company"><?=e($s['name'])?></span><span class="table-sub">Поставщик</span></td>
        <td data-label="Контактное лицо"><?=e($s['contact_person']??'—')?></td>
        <td data-label="Телефон"><?=e($s['phone']??'—')?></td>
        <td data-label="Действия"><div class="d-flex gap-2 justify-content-end">
          <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/suppliers/edit/'.$s['id'])) ?>">Изменить</a>
          <form method="post" action="<?= e(url('/suppliers/delete/'.$s['id'])) ?>" onsubmit="return confirm('Точно удалить?')"><button class="btn btn-sm btn-outline-danger">Удалить</button></form>
        </div></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php else: ?>
    <div class="empty-state"><div class="empty-icon">◫</div><div class="fw-bold mb-1">Поставщиков пока нет</div><div class="small mb-3">Добавьте первую компанию, чтобы начать.</div><a class="btn btn-primary btn-sm" href="<?= e(url('/suppliers/create')) ?>">Добавить поставщика</a></div>
  <?php endif; ?>
</div>
<?php $content=ob_get_clean(); include __DIR__.'/../layout.php'; ?>