<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $editing = !empty($supplier['id']); $title=$editing?'Редактирование':'Добавление'; ob_start(); ?>
<div class="page-header">
  <div><div class="page-kicker">Поставщики</div><h1 class="page-title"><?=$title?> поставщика</h1><p class="page-subtitle">Заполните основные контактные данные компании.</p></div>
  <a class="btn btn-secondary" href="<?= e(url('/suppliers')) ?>">← Назад</a>
</div>
<div class="row">
  <div class="col-xl-8">
    <div class="card"><div class="card-body p-4">
      <?php foreach($errors as $error): ?><div class="alert alert-danger mb-3"><?=e($error)?></div><?php endforeach; ?>
      <form method="post" action="<?=e($action)?>" data-validate>
        <div class="mb-4"><label class="form-label">Название компании *</label><input class="form-control" name="name" placeholder="Например, ООО «Компания»" required value="<?=e($supplier['name']??'')?>"></div>
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">Контактное лицо</label><input class="form-control" name="contact_person" placeholder="Имя и фамилия" value="<?=e($supplier['contact_person']??$supplier['contact']??'')?>"></div>
          <div class="col-md-6"><label class="form-label">Телефон</label><input class="form-control" name="phone" placeholder="+370 600 00 000" value="<?=e($supplier['phone']??'')?>"></div>
        </div>
        <div class="d-flex gap-2 mt-4"><button class="btn btn-primary">Сохранить</button><a class="btn btn-secondary" href="<?= e(url('/suppliers')) ?>">Отмена</a></div>
      </form>
    </div></div>
  </div>
</div>
<?php $content=ob_get_clean(); include __DIR__.'/../layout.php'; ?>