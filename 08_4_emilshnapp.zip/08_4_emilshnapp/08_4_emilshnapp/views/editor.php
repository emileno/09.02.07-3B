<?php if (!defined('APP_RUNNING')) { header('Location: ../'); exit; } ?>
<?php $title='Редактор'; ob_start(); ?>
<div class="page-header">
  <div><div class="page-kicker">Инструменты</div><h1 class="page-title">Текстовый редактор</h1><p class="page-subtitle">Изменяйте содержимое рабочего файла прямо в браузере.</p></div>
</div>
<?php if (!empty($saved)): ?><div class="alert alert-success mb-3">Текст сохранён.</div><?php endif; ?>
<div class="card"><div class="toolbar"><div><div class="toolbar-title">storage/text.txt</div><div class="toolbar-meta">Обычный текстовый файл</div></div></div>
<div class="editor-wrap"><form method="post" action="<?= e(url('/editor')) ?>"><textarea class="editor" name="content" rows="18"><?= e($editorText ?? '') ?></textarea><button class="btn btn-primary mt-3">Сохранить изменения</button></form></div></div>
<?php $content=ob_get_clean(); include __DIR__.'/layout.php'; ?>